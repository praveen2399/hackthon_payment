const express = require("express");
const mysql = require("mysql2");
const generator = require('creditcard-generator');
const faker = require("faker");

// Create connection
const db = mysql.createConnection({
    host: "localhost",  
    user: "root",  
    // host: "uniserve.mysql.database.azure.com", 
    // user: "uniserveadmin",  
    password: "Packard555"
  });

// Connect to MySQL
db.connect((err) => {  
    if (err) {  
      throw err;  
    }  
    console.log("MySql Connected");
  });

const app = express();

app.get("/createdb", (req, res) => {
    let sql = "CREATE DATABASE uniserve";  
    db.query(sql, (err) => {  
      if (err) {  
        throw err;  
      }  
      res.send("Database created");
    });  
  });

  app.get("/createemployeetable", (req, res) => {
    let sql =  
      "CREATE TABLE uniserve.employee(id int AUTO_INCREMENT, name VARCHAR(255), designation VARCHAR(255), PRIMARY KEY(id))";
  
    db.query(sql, (err) => {
      if (err) {  
        throw err;  
      }
  
      res.send("Employee table created");
    });  
  });

  app.get("/createemployees", (req, res) => {
    let post = { id : 1, name: "Steve Smith", designation: "Service Advisor" };
    let sql = "INSERT INTO uniserve.employee SET ?";
    let query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  

    post = { id : 2, name: "Virat Kumar", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  

    post = { id : 3, name: "Kane Williamson", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  

    post = { id : 4, name: "Richard Byford", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  

    post = { id : 5, name: "Ian Morgan", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  
    
    post = { id : 6, name: "Kuldeep Patel", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });
        
    post = { id : 7, name: "Tristan Heng", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  
        
    post = { id : 8, name: "John Fitzgerald", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  
        
    post = { id : 9, name: "Merv Hughes", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  
        
    post = { id : 10, name: "Oliver Yuan", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  
        
    post = { id : 11, name: "Siva Kumar", designation: "Service Advisor" };
    query = db.query(sql, post, (err) => {
        if (err) {
            throw err;
        }
    });  

    res.send("Employees added");
  });

  app.get("/listemployees", (req, res) => {
    let sql =  
      "SELECT * FROM uniserve.employee";
      db.query(sql, (err, rows) => {
        if(err) throw err;  
        console.log(rows);   
        res.send(rows);
      });  
  });

  app.get("/deleteemployees", (req, res) => {
    let sql =  
      "DELETE FROM uniserve.employee";
      db.query(sql, (err) => {
        if(err) throw err;  
        res.send("Employee table cleared!");
      });  
  });

  app.get("/createcustomertable", (req, res) => {
    let sql =  
      "CREATE TABLE uniserve.customer(id int AUTO_INCREMENT, " 
       + " firstname VARCHAR(255), "
       + " lastname VARCHAR(255), "
       + " title VARCHAR(100), "
       + " phone VARCHAR(30), "
       + " address VARCHAR(255), "
       + " address2 VARCHAR(255), "
       + " city VARCHAR(100), "
       + " state VARCHAR(50), "
       + " zip VARCHAR(10), "
       + " email VARCHAR(100), "
       + " creditcard VARCHAR(30), "
       + " PRIMARY KEY(id))";
  
    db.query(sql, (err) => {
      if (err) {  
        throw err;  
      }
  
      res.send("Customer table created");
    });  
  });
 
  app.get("/createfakecustomers", (req, res) => {
    let sql = "INSERT INTO uniserve.customer SET ?";
    for (i = 0; i < 200; i++) {
        var firstName = faker.name.firstName();
        var lastName = faker.name.lastName();
        var title = faker.name.title();
        var phone = faker.phone.phoneNumber();
        var address = faker.address.streetAddress();
        var address2 = faker.address.secondaryAddress();
        var city = faker.address.city();
        var state = faker.address.state();
        var zip = faker.address.zipCode();
        var email = faker.internet.email(); 
        var creditCard = generator.GenCC();
        post = { 
            "firstName": firstName, 
            "lastName": lastName,
            "title": title,
            "phone": phone,
            "address": address,
            "address2": address2,
            "city": city,
            "state": state,
            "zip": zip,
            "email": email,
            "creditCard": creditCard 
            };
        query = db.query(sql, post, (err) => {
            if (err) {
                throw err;
            }
        });  
    }
     res.send("Fake customers are created!"); 
  });

  app.get("/listcustomers/:page", (req, res) => {
    let sql =  
      "SELECT * FROM uniserve.customer LIMIT " + req.params.page  + ", 10";
      db.query(sql, (err, rows) => {
        if(err) throw err;  
        console.log(rows);   
        res.send(rows);
      });  
  });

  app.get("/searchcustomers", (req, res) => {
    var lastName = req.query.lastName
    var firstName = req.query.firstName

    var params = [firstName.toUpperCase(), lastName.toUpperCase()];
    let sql =  
      "SELECT * FROM uniserve.customer WHERE upper(firstname) = ? and upper(lastname) = ?";
      db.query(sql, params, (err, rows) => {
        if(err) throw err;  
        res.send(rows);
      });  
  });

  var problems_list = [
    "Engine And Engine Cooling - Vehicle",	
    "Electrical System - Vehicle",	
    "Power Train - Vehicle",	
    "Air Bag - Vehicle",	
    "Service Brakes - Vehicle",	
    "Steering - Vehicle",	
    "White Labeling - Digital Mktg",
    "Paid Ad Spend - Digital Mktg",
    "Target Audience - Digital Mktg",
    "Social Media - Digital Mktg",
    "Vaccum Carpets - Home Services",
    "Dust blines, window sills - Home Services",
    "Shine fixtures - Home Services",
    "Spring/Deep clean - Home Services",
    "Landscapping - Home Services",
    "iPhone 11 Pro Max - Electronics",
    "iPhone 11 Pro Repair/Replacement - Electronics",
    "iPhone 11 Repair/Replacement - Electronics",
    "iPhone XS Max Repair/Replacement - Electronics",
    "iPhone XR Repair/Replacement - Electronics",
    "iPhone XS Repair/Replacement - Electronics",
    "iPhone X Repair/Replacement - Electronics",
    "iPhone 8 Plus Repair - Electronics",
    "iPhone 8 Repair Services - Electronics",
    "iPhone 7 Plus Repair (7+) - Electronics",
    "iPhone 7 Repair Services - Electronics",
    "iPhone 6S Plus Repair (6S+ services) - Electronics"


  ];

var service_statuses = [
    "Identified",
    "Shared with customer",
    "Approved by customer",
    "Declined by customer",
    "Completed",
    "Paid"
];

var employee_id_min = 1;
var employee_id_max = 11;

var customer_id_min = 1;
var customer_id_max = 200;

var doc_id_min = 10000;
var doc_id_max = 15000;

app.get("/createservicerecordstable", (req, res) => {
    let sql =  
        "CREATE TABLE uniserve.service_records(id int AUTO_INCREMENT, " 
        + " employee_id int not null, "
        + " customer_id int not null, "
        + " problem VARCHAR(100), "
        + " service_cost DECIMAL(5,2), "
        + " service_date DATE, "
        + " service_status VARCHAR(100), "
        + " service_doc_id int, "
        + " PRIMARY KEY(id))";
    
    db.query(sql, (err) => {
        if (err) {  
        throw err;  
        }
    
        res.send("Service Records table created");
    });  
});
    
app.get("/createservicerecords", (req, res) => {     
    let sql = "INSERT INTO uniserve.service_records SET ?";
    for (i = 0; i < 2000; i++) {
        var random_customer_id =  Math.floor(Math.random() * (customer_id_max - customer_id_min) + customer_id_min);
        var random_employee_id =  Math.floor(Math.random() * (employee_id_max - employee_id_min) + employee_id_min);
        var random_doc_id =  Math.floor(Math.random() * (doc_id_max - doc_id_min) + doc_id_min);
        var random_problem_index =  Math.floor(Math.random() * (problems_list.length));
        var random_status_index =  Math.floor(Math.random() * (service_statuses.length));

        // Service records for the same problem. 
        for( let x = 0 ; x < 3; x++) {
          var problem = problems_list[random_problem_index];
          var service_cost = faker.commerce.price(100, 200);
          var service_date = faker.date.between("2022-01-01T00:00:00.000Z", "2024-01-01T00:00:00.000Z");        
          var service_status = service_statuses[random_status_index];

          post = { 
              "employee_id": random_employee_id, 
              "customer_id": random_customer_id,
              "problem": problem,
              "service_cost": service_cost,
              "service_date": service_date,
              "service_status": service_status,
              "service_doc_id": random_doc_id
          };

          query = db.query(sql, post, (err) => {
              if (err) {
                  throw err;
              }
          });  
        }
    }
  res.send("Fake service records are created!"); 
});

app.get("/searchservicerecords", (req, res) => {
        var lastName = req.query.lastName
        var firstName = req.query.firstName
    
        var params = [firstName.toUpperCase(), lastName.toUpperCase()];
        let sql =  
          "select * " +
          "from " +
          "uniserve.customer C " +
          "LEFT JOIN " +
          "uniserve.service_records SR " +
          "on C.id = SR.customer_id " +
          "LEFT JOIN " +
          "uniserve.employee E " +
          "on E.id = SR.employee_id WHERE upper(firstname) = ? and upper(lastname) = ?";
          
          db.query(sql, params, (err, rows) => {
            if(err) throw err;  
            res.send(rows);
          });  
});

app.listen("3000", () => {
  console.log("Server started on port 3000");
});