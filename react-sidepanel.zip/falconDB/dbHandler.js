import * as sqlite3  from "sqlite3";
const db = new sqlite3.default.Database('falconDB/falconDb');
const dbfile = 'falconDb';
